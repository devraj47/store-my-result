<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/result.css">
    

    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
  
    <title>Enter marks</title>
</head>
<body > 
<br>
    <div class="main">
        <form action="test.php" method="post">
        <fieldset>
        <div class="simple-form">
        <img src="images/logo.png"  >
            <legend>STORE MY RESULT</legend>
          

            
            <input type="text" name="rollno" placeholder="rollno" autocomplete="off">
            <input type="text" name="course" placeholder="course" autocomplete="off">
            <input type="text" name="semester" placeholder="semester" autocomplete="off">
           
                <table id="myTable">
                    <tr>
                        <th>Subject Name</th>
                        <th>Marks</th>
                    </tr>
                    <tr>
                        <td><input type="text" name="subject1" id="" placeholder="Subject 1" autocomplete="off"></td>
                        <td><input type="text" name="mark1" id="" placeholder="Mark 1" autocomplete="off"></td>
                        
                    </tr>
                    <tr>
                        <td><input type="text" name="subject2" id="" placeholder="Subject 2" autocomplete="off"></td>
                        <td><input type="text" name="mark2" id="" placeholder="Mark 2" autocomplete="off"></td>
                        
                    </tr>
                    <tr>
                        <td><input type="text" name="subject3" id="" placeholder="Subject 3" autocomplete="off"></td>
                        <td><input type="text" name="mark3" id="" placeholder="Mark 3" autocomplete="off"></td>
                        
                    </tr>
                    <tr>
                        <td><input type="text" name="subject4" id="" placeholder="Subject 4" autocomplete="off"></td>
                        <td><input type="text" name="mark4" id="" placeholder="Mark 4" autocomplete="off"></td>
                        
                    </tr>
                    <tr>
                        <td><input type="text" name="subject5" id="" placeholder="Subject 5" autocomplete="off"></td>
                        <td><input type="text" name="mark5" id="" placeholder="Mark 5" autocomplete="off"></td>
                        
                    </tr>
                    <tr>
                        <td><input type="text" name="subject6" id="" placeholder="Subject 6" autocomplete="off"></td>
                        <td><input type="text" name="mark6" id="" placeholder="Mark 6" autocomplete="off"></td>
                        
                    </tr>
                    <tr>
                        <td><input type="text" name="subject7" id="" placeholder="Subject 7" autocomplete="off"></td>
                        <td><input type="text" name="mark7" id="" placeholder="Mark 7" autocomplete="off"></td>
                        
                    </tr>
                    <tr>
                        <td><input type="text" name="subject8" id="" placeholder="Subject 8" autocomplete="off"></td>
                        <td><input type="text" name="mark8" id="" placeholder="Mark 8" autocomplete="off"></td>
                        
                    </tr>
                </table>
                <input type="submit" value="Submit">
        </fieldset>
        </form>
    </div>

</body>
</html>